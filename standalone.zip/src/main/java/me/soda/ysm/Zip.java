package me.soda.ysm;

import java.io.FileOutputStream;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Zip {
    public static void generate(Map<String, byte[]> in, String out) throws Exception {
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out));
        for (Map.Entry<String, byte[]> e : in.entrySet()) {
            zos.putNextEntry(new ZipEntry(e.getKey()));
            zos.write(e.getValue());
            zos.closeEntry();
        }
        zos.close();
    }
}
