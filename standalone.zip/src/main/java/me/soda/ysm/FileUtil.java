package me.soda.ysm;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class FileUtil {
    public static byte[] readBytes(File file) {
        try {
            return Files.readAllBytes(file.toPath());
        } catch (IOException ignored) {
            throw new RuntimeException();
        }
    }
}
