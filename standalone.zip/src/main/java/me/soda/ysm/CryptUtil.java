package me.soda.ysm;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.spec.AlgorithmParameterSpec;

public final class CryptUtil {
    public static ByteArrayOutputStream decrypt(SecretKey secretKey, AlgorithmParameterSpec algorithmParameterSpec, byte[] bArr) throws IOException, GeneralSecurityException {
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(2, secretKey, algorithmParameterSpec);
        byte[] bArr2 = new byte[64];
        while (true) {
            int read = byteArrayInputStream.read(bArr2);
            if (read == -1) {
                break;
            }
            byte[] update = cipher.update(bArr2, 0, read);
            if (update != null) {
                byteArrayOutputStream.write(update);
            }
        }
        byte[] doFinal = cipher.doFinal();
        if (doFinal != null) {
            byteArrayOutputStream.write(doFinal);
        }
        return byteArrayOutputStream;
    }

    public static SecretKey m230x5922c923(byte[] bArr) {
        return new SecretKeySpec(bArr, "AES");
    }
}
