package me.soda.ysm;

public final class MagicNumberUtil {
    public static int getMagicNumber(byte[] bArr, int i) {
        int i2 = 4;
        int i3 = 0;
        int i4 = i + 4;
        for (int i5 = i; i5 < i4; i5++) {
            i2--;
            i3 += (bArr[i5] & 255) << (i2 * 8);
        }
        return i3;
    }
}
