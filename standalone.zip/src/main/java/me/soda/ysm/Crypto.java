package me.soda.ysm;

import it.unimi.dsi.fastutil.Pair;
import it.unimi.dsi.fastutil.bytes.ByteArrays;

import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.*;
import java.util.zip.DataFormatException;

public class Crypto {
    public static Map<String, byte[]> decrypt(File file) throws IOException, DataFormatException, GeneralSecurityException {
        Pair<String, byte[]> pair = null;
        byte[] readFileToByteArray = FileUtil.readBytes(file);
        int magicNumber = MagicNumberUtil.getMagicNumber(readFileToByteArray, 0);
        int version = MagicNumberUtil.getMagicNumber(readFileToByteArray, 4);
        if (magicNumber != 1498629968) {
            return Collections.emptyMap();
        }
        if (version == 1 || version == 2) {
            byte[] key = ByteArrays.copy(readFileToByteArray, 8, 16);
            byte[] data = ByteArrays.copy(readFileToByteArray, 24, readFileToByteArray.length - 24);
            if (Arrays.equals(key, Hasher.hash(data))) {
                Map<String, byte[]> resultMap = new HashMap<>();
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
                while (byteArrayInputStream.available() > 0) {
                    if (version == 1) {
                        try {
                            pair = decryptV1(byteArrayInputStream);
                        } catch (GeneralSecurityException | DataFormatException e) {
                            e.printStackTrace();
                        }
                    } else {
                        pair = decryptV2(byteArrayInputStream);
                    }
                    resultMap.put(pair.left(), pair.right());
                }
                return resultMap;
            }
            return Collections.emptyMap();
        }
        return Collections.emptyMap();
    }

    private static Pair<String, byte[]> decryptV1(ByteArrayInputStream byteArrayInputStream) throws IOException, GeneralSecurityException, DataFormatException {
        String key = readString(byteArrayInputStream);
        int length = readInt(byteArrayInputStream);
        byte[] keyBytes = new byte[16];
        byte[] ivBytes = new byte[16];
        byteArrayInputStream.read(keyBytes);
        byteArrayInputStream.read(ivBytes);
        SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(ivBytes);
        byte[] dataBytes = new byte[length];
        byteArrayInputStream.read(dataBytes);
        return Pair.of(key, CompressUtil.decompress(CryptUtil.decrypt(secretKeySpec, ivParameterSpec, dataBytes).toByteArray()));
    }

    private static Pair<String, byte[]> decryptV2(ByteArrayInputStream byteArrayInputStream) throws IOException, GeneralSecurityException, DataFormatException {
        String key = readBase64String(byteArrayInputStream);
        int length = readInt(byteArrayInputStream);
        byte[] dataBytes = new byte[readInt(byteArrayInputStream)];
        byte[] ivBytes = new byte[16];
        byte[] keyBytes = new byte[length];
        byteArrayInputStream.read(dataBytes);
        byteArrayInputStream.read(ivBytes);
        byteArrayInputStream.read(keyBytes);
        SecretKey m230x5922c923 = CryptUtil.m230x5922c923(generateRandomBytes(keyBytes));
        IvParameterSpec ivParameterSpec = new IvParameterSpec(ivBytes);
        return Pair.of(key, CompressUtil.decompress(CryptUtil.decrypt(CryptUtil.m230x5922c923(CryptUtil.decrypt(m230x5922c923, ivParameterSpec, dataBytes).toByteArray()), ivParameterSpec, keyBytes).toByteArray()));
    }

    private static byte[] generateRandomBytes(byte[] data) {
        byte[] randomBytes = new byte[16];
        new Random(hashToLong(Hasher.hash(data))).nextBytes(randomBytes);
        return randomBytes;
    }

    private static long hashToLong(byte[] data) {
        long result = 0;
        for (byte b : data) {
            result = (result << 8) + (b & 255);
        }
        return result;
    }

    private static String readString(ByteArrayInputStream byteArrayInputStream) throws IOException {
        byte[] bytes = new byte[readInt(byteArrayInputStream)];
        byteArrayInputStream.read(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static String readBase64String(ByteArrayInputStream byteArrayInputStream) throws IOException {
        byte[] bytes = new byte[readInt(byteArrayInputStream)];
        byteArrayInputStream.read(bytes);
        return new String(Base64.getDecoder().decode(bytes), StandardCharsets.UTF_8);
    }

    private static int readInt(ByteArrayInputStream byteArrayInputStream) throws IOException {
        byte[] bytes = new byte[4];
        byteArrayInputStream.read(bytes);
        return MagicNumberUtil.getMagicNumber(bytes, 0);
    }

}
