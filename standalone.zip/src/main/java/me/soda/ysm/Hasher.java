package me.soda.ysm;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class Hasher {
    private static final MessageDigest f475x5922c923;

    static {
        try {
            f475x5922c923 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public static byte[] hash(byte[] bArr) {
        return f475x5922c923.digest(bArr);
    }
}
