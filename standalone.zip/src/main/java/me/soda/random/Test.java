package me.soda.random;

public class Test {
    public static void main(String[] args) {
        for (long aLong = 0L; aLong < Integer.MAX_VALUE; aLong++) {
            aLong = aLong + 1;
        }
    }
}
