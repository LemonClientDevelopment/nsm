package me.soda;

import me.soda.ysm.Crypto;
import me.soda.ysm.Zip;

import java.io.File;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        //String k = "129926891522151413914919201812015183332119518191914139149192018120151818181818239144152319191919";
        //System.out.println(HWID.fromHWID(k));
        try {
            Map<String, byte[]> k = Crypto.decrypt(new File("D:\\Storage\\游戏\\MC\\ysms\\lingsha.ysm"));
            Zip.generate(k, "out.zip");
        } catch (Exception ignored) {

        }
    }
}