package me.soda.hwid;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HWID {
    public static String fromHWID(String hwid) {
        StringBuilder sb = new StringBuilder();
        List<String> cache = new ArrayList<>();
        for (char c : hwid.toCharArray()) {
            String s = Character.toString(c);
            if (cache.isEmpty()) {
                cache.add(s);
                continue;
            }
            String num = cache.get(0) + s;
            if (num.indexOf("-") == 1) {
                cache.clear();
                continue;
            }
            if (Integer.parseInt(num) > alphabet.size()) {
                sb.append(fromStr(cache.get(0)));
                cache.clear();
                cache.add(s);
            } else {
                sb.append(fromStr(num));
                cache.clear();
            }
        }
        return sb.toString();
    }

    public static Map<String, Integer> alphabet = new HashMap<>() {{
        int cp = 'a';
        for (int i = cp; i < cp + 26; i++) {
            put(Character.toString(i), i - cp + 1);
        }
    }};

    public static String fromStr(String letter) {
        return alphabet.entrySet().stream()
                .filter(entry -> letter.equals(entry.getValue().toString()))
                .findFirst()
                .map(Map.Entry::getKey)
                .orElse("?");
    }
}
